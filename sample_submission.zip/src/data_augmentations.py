from torchvision import datasets, transforms
import torch.nn as nn

resize_to_64x64 = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor()
])

resize_and_colour_jitter = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor()
])

my_custom_data_augmentation = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ColorJitter(brightness=0.1, contrast=0.1),
    transforms.ToTensor()
])

# Shouldn't have any source of randomness in the final evaluation pipeline
# because it would perturb the input, making the predictions
# different every time we evaluate the model.
my_evaluation_pipeline = transforms.Compose([
    transforms.Resize((32, 32)),
    transforms.ToTensor()
])